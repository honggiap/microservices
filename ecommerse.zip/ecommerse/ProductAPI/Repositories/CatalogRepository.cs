﻿using ProductAPI.Context;
using ProductAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ProductAPI.Repositories
{
    public class CatalogRepository: ICatalogRepository 
    {
        private ProductContext _context;

        public CatalogRepository(ProductContext context)
        {
            _context = context;
        }
        public void AddCatalog(Catalog catalog)
        {
            _context.Catalogs.Add(catalog);
            _context.SaveChanges();

        }

        public Catalog Get(int id)
        {
            return _context.Catalogs.Where(f => f.CatalogID == id).FirstOrDefault();

        }

        public ICollection<Catalog> Get()
        {
            return _context.Catalogs.ToList();
        }
    }
}
