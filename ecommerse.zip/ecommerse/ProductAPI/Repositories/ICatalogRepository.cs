﻿using ProductAPI.Models;
using System.Collections.Generic;

namespace ProductAPI.Repositories
{
    public interface ICatalogRepository
    {
        void AddCatalog(Catalog catalog);
        Catalog Get(int id);
        ICollection<Catalog> Get();
    }
}