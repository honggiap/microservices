﻿using Microsoft.EntityFrameworkCore;
using ProductAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ProductAPI.Context
{
    public class ProductContext: DbContext
    {
        public ProductContext(DbContextOptions<ProductContext> options) : base(options)
        {
            this.Database.EnsureCreated();
        }

        public DbSet<Product> Products { get; set; }
        public DbSet<Catalog> Catalogs { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Catalog>().HasMany(c => c.Products).WithOne(p => p.Catalog);
            modelBuilder.Entity<Product>().Property(b => b.Cost).HasColumnType<Decimal>("decima(8.4)");
            modelBuilder.Entity<Product>().Property(b => b.Price).HasColumnType<Decimal>("decima(8.4)");
            base.OnModelCreating(modelBuilder);
        }

    }
}
