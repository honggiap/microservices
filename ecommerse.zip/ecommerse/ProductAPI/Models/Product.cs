﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace ProductAPI.Models
{
    public class Product
    {
        [Key]
        public int ProductId { get; set; }
        public string ProductName { get; set; }
        public decimal Price { get; set; }
        public decimal Cost { get; set; }
        public long AvailableQuantity { get; set; }
        public long ReorderPoint { get; set; }

        [ForeignKey("Catalog")]
        public int CatalogRefId { get; set; }
        public Catalog Catalog { get; set; }
    }
}
