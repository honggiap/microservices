﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace ProductAPI.Models
{
    public class Catalog
    {
        [Key]
        public int CatalogID { get; set; }
        public string CatalogName { get; set; }


        public ICollection<Product> Products { get; set; }
    }
}
