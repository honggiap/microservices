﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using ProductAPI.Models;
using ProductAPI.Repositories;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace ProductAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CatalogController : ControllerBase
    {
        private ICatalogRepository _icat;

        public CatalogController(ICatalogRepository icat)
        {
            _icat = icat;
        }
        // GET: api/<CatalogController>
        [HttpGet]
        public IEnumerable<Catalog> Get()
        {
            return _icat.Get();
        }

        // GET api/<CatalogController>/5
        [HttpGet("{id}")]
        public Catalog Get(int id)
        {
            return _icat.Get(id);
        }

        // POST api/<CatalogController>
        [HttpPost]
        public void Post([FromBody] Catalog value)
        {
            _icat.AddCatalog(value);
        }

        // PUT api/<CatalogController>/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] string value)
        {
        }

        // DELETE api/<CatalogController>/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}
